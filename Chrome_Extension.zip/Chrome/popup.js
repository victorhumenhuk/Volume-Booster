const MESSAGE_GET_STATUS = "GET_STATUS";
const MESSAGE_SET_VOLUME = "SET_VOLUME";
const MESSAGE_ACTIVE_TAB = "ACTIVE_TAB_REQUEST";

const statusEl = document.getElementById("status");
const detailEl = document.getElementById("detail");
const badgeEl = document.getElementById("volumeBadge");
const slider = document.getElementById("volumeSlider");
const valueEl = document.getElementById("volumeValue");
const btn100 = document.getElementById("set100");
const btn200 = document.getElementById("set200");
const btn400 = document.getElementById("set400");
const btnMax = document.getElementById("setMax");
const buttons = [btn100, btn200, btn400, btnMax];

function setBusy(isBusy) {
  slider.disabled = isBusy;
  for (const button of buttons) {
    button.disabled = isBusy;
  }
}

function updateSliderVisuals(volume) {
  const isBoosted = volume > 100;
  valueEl.textContent = `${volume}%`;
  valueEl.classList.toggle("is-boosted", isBoosted);
  slider.classList.toggle("is-boosted", isBoosted);
  slider.value = volume;

  for (const button of buttons) {
    const matches = Number(button.dataset.volume) === volume;
    button.setAttribute("aria-pressed", String(matches));
    button.classList.toggle("is-selected", matches);
  }
}

function setBadge(state, label) {
  badgeEl.dataset.state = state;
  statusEl.textContent = label;
}

function describeStatus(response) {
  const media =
    response.mediaCount === 0
      ? "No media found on page"
      : response.mediaCount === 1
        ? "1 media element on page"
        : `${response.mediaCount} media elements on page`;

  if (response.volume > 100) {
    return {
      state: "boosted",
      label: `Boosted to ${response.volume}%`,
      detail: `${media}.`
    };
  }

  return {
    state: "normal",
    label: "Normal volume",
    detail: `${media}.`
  };
}

async function requestActiveTab(action, volume) {
  return chrome.runtime.sendMessage({
    type: MESSAGE_ACTIVE_TAB,
    action,
    volume
  });
}

async function refreshStatus() {
  setBusy(true);

  try {
    const response = await requestActiveTab(MESSAGE_GET_STATUS);

    if (!response?.ok) {
      setBadge("error", "Page not controllable");
      detailEl.textContent = "This page cannot be boosted.";
      return;
    }

    updateSliderVisuals(response.volume);
    const { state, label, detail } = describeStatus(response);
    setBadge(state, label);
    detailEl.textContent = detail;
  } catch {
    setBadge("error", "Page not controllable");
    detailEl.textContent = "This page cannot be boosted.";
  } finally {
    setBusy(false);
  }
}

async function applyVolume(volume) {
  setBusy(true);
  updateSliderVisuals(volume);
  setBadge("normal", "Applying...");
  detailEl.textContent = "";

  try {
    const response = await requestActiveTab(MESSAGE_SET_VOLUME, volume);

    if (!response?.ok) {
      setBadge("error", "Unable to update");
      detailEl.textContent = "This page cannot be boosted.";
      return;
    }

    updateSliderVisuals(response.volume);
    const { state, label, detail } = describeStatus(response);
    setBadge(state, label);
    detailEl.textContent = detail;
  } catch {
    setBadge("error", "Unable to update");
    detailEl.textContent = "This page cannot be boosted.";
  } finally {
    setBusy(false);
  }
}

let sliderTimeout = null;
slider.addEventListener("input", () => {
  const volume = Number(slider.value);
  updateSliderVisuals(volume);

  clearTimeout(sliderTimeout);
  sliderTimeout = setTimeout(() => applyVolume(volume), 60);
});

for (const button of buttons) {
  button.addEventListener("click", () => {
    clearTimeout(sliderTimeout);
    const volume = Number(button.dataset.volume);
    applyVolume(volume);
  });
}

void refreshStatus();
