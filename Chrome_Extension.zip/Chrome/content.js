const MESSAGE_GET_STATUS = "GET_STATUS";
const MESSAGE_SET_VOLUME = "SET_VOLUME";

let audioCtx = null;
const nodes = new WeakMap();
const tracked = new WeakSet();
let currentGain = 1;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }

  if (audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }

  return audioCtx;
}

function getOrCreateNodes(media) {
  if (nodes.has(media)) {
    return nodes.get(media);
  }

  try {
    const ctx = getAudioContext();
    const source = ctx.createMediaElementSource(media);
    const gainNode = ctx.createGain();

    source.connect(gainNode);
    gainNode.connect(ctx.destination);

    const entry = { source, gainNode };
    nodes.set(media, entry);
    return entry;
  } catch {
    return null;
  }
}

function applyGain(media) {
  if (currentGain === 1 && !nodes.has(media)) {
    return;
  }

  const entry = getOrCreateNodes(media);
  if (!entry) {
    return;
  }

  entry.gainNode.gain.value = currentGain;
}

function collectMedia(root, collected = [], seen = new Set()) {
  if (!root || typeof root.querySelectorAll !== "function") {
    return collected;
  }

  if ((root instanceof HTMLVideoElement || root instanceof HTMLAudioElement) && !seen.has(root)) {
    seen.add(root);
    collected.push(root);
  }

  for (const el of root.querySelectorAll("video, audio")) {
    if (!seen.has(el)) {
      seen.add(el);
      collected.push(el);
    }
  }

  for (const el of root.querySelectorAll("*")) {
    if (el.shadowRoot) {
      collectMedia(el.shadowRoot, collected, seen);
    }
  }

  return collected;
}

function syncAllMedia() {
  for (const media of collectMedia(document)) {
    trackMedia(media);
    applyGain(media);
  }
}

function trackMedia(media) {
  if (tracked.has(media)) {
    return;
  }

  tracked.add(media);

  const handler = () => applyGain(media);
  media.addEventListener("play", handler, { passive: true });
  media.addEventListener("loadedmetadata", handler, { passive: true });

  if (currentGain !== 1) {
    applyGain(media);
  }
}

function installObserver() {
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (!(node instanceof Element)) {
          continue;
        }

        if (node instanceof HTMLVideoElement || node instanceof HTMLAudioElement) {
          trackMedia(node);
        }

        for (const media of collectMedia(node)) {
          trackMedia(media);
        }
      }
    }
  });

  const target = document.documentElement || document;
  observer.observe(target, { childList: true, subtree: true });
}

function getStatus() {
  const allMedia = collectMedia(document);
  const boostedCount = allMedia.filter((m) => nodes.has(m)).length;

  return {
    ok: true,
    gain: currentGain,
    volume: Math.round(currentGain * 100),
    mediaCount: allMedia.length,
    boostedCount
  };
}

function setVolume(volumePercent) {
  const clamped = Math.max(100, Math.min(600, Number(volumePercent) || 100));
  currentGain = clamped / 100;
  syncAllMedia();
  return getStatus();
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message?.type) {
    return;
  }

  if (message.type === MESSAGE_GET_STATUS) {
    sendResponse(getStatus());
    return;
  }

  if (message.type === MESSAGE_SET_VOLUME) {
    sendResponse(setVolume(message.volume));
  }
});

installObserver();

for (const media of collectMedia(document)) {
  trackMedia(media);
}
