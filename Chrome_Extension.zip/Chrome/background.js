const MESSAGE_GET_STATUS = "GET_STATUS";
const MESSAGE_SET_VOLUME = "SET_VOLUME";
const MESSAGE_ACTIVE_TAB = "ACTIVE_TAB_REQUEST";

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id ?? null;
}

async function sendToActiveTab(message) {
  const tabId = await getActiveTabId();
  if (!tabId) {
    return { ok: false, reason: "no-tab" };
  }

  try {
    const response = await chrome.tabs.sendMessage(tabId, message);
    return response ?? { ok: false, reason: "no-response" };
  } catch {
    return { ok: false, reason: "not-allowed" };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== MESSAGE_ACTIVE_TAB) {
    return;
  }

  (async () => {
    if (message.action === MESSAGE_GET_STATUS) {
      const response = await sendToActiveTab({ type: MESSAGE_GET_STATUS });
      sendResponse(response);
      return;
    }

    if (message.action === MESSAGE_SET_VOLUME) {
      const response = await sendToActiveTab({
        type: MESSAGE_SET_VOLUME,
        volume: message.volume ?? 100
      });
      sendResponse(response);
      return;
    }

    sendResponse({ ok: false, reason: "unknown-action" });
  })();

  return true;
});
